/** Small presentation helpers shared by workspace components. */
export const element =                                      (id        ) =>
    document.getElementById(id)     ;

export function escapeHtml(value         )         {
    const entities                         = {
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    };
    return String(value).replace(/[&<>"']/g, character => entities[character]);
}

/** Retain the established significant-digit display and numerical zero threshold. */
export function formatNumber(value        , digits = 3)         {
    return Math.abs(value) < 1e-8 ? '0' : Number(value.toPrecision(digits)).toString();
}

export function downloadJson(name        , data         )       {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}
