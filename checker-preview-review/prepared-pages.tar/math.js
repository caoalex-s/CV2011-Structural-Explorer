/** LaTeX rendering shared by computed equations and the course method rules. */
import katex from 'katex';

const escapeHtml = (text        ) => text.replace(/[&<>"']/g, character =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character] ));

                           
                  
                       
                  
                  
                 
                           
                                
                          
                               
                          
 

export function math(source        , display = false)         {
    try {
        return katex.renderToString(source, {
            displayMode: display,
            output: 'htmlAndMathml',
            throwOnError: true,
            strict: 'error',
            trust: false,
            maxExpand: 1000,
            maxSize: 20,
        });
    } catch {
        // Preserve the expression and make a rendering failure explicit.
        return `<code class="math-error" aria-label="Equation could not be typeset">${escapeHtml(source)}</code>`;
    }
}

export function rationalLatex(value        )         {
    const fraction = /^(-?\d+)\/(\d+)$/.exec(value);
    return fraction ? `\\frac{${fraction[1]}}{${fraction[2]}}` : value;
}

/** Format a rounded number as LaTeX, including powers of ten. */
export function numberLatex(value        , significantDigits = 6)         {
    const rounded = Number(value.toPrecision(significantDigits));
    return String(rounded).replace(/e([+-]?\d+)/, (_, exponent        ) => `\\times10^{${Number(exponent)}}`);
}

/** Show a formula, the inserted parameter values, and its evaluated result. */
export function equationHtml(row          )         {
    const units                         = {
        'kN': String.raw`\mathrm{kN}`, 'kN m': String.raw`\mathrm{kN}\,\mathrm{m}`,
        'kN/m': String.raw`\mathrm{kN}/\mathrm{m}`, 'm': String.raw`\mathrm{m}`,
        'mm': String.raw`\mathrm{mm}`, 'rad': String.raw`\mathrm{rad}`, 'mrad': String.raw`\mathrm{mrad}`,
        'kN m²': String.raw`\mathrm{kN}\,\mathrm{m}^2`, 'kN m³': String.raw`\mathrm{kN}\,\mathrm{m}^3`,
    };
    const unit = units[row.unit];
    const relation = row.approximate ? '\\approx' : '=';
    const inserted = row.substitutionLatex && row.substitutionLatex !== row.latex
        ? `= ${row.substitutionLatex}${row.symbolicUnit ? `\\;${units[row.symbolicUnit]}` : ''} ${relation} ` : `${relation} `;
    const source = `${row.labelLatex} ${inserted}${row.latex}${unit ? `\\;${unit}` : ''}`;
    const symbolic = row.symbolicLatex === undefined ? '' : `<div class="symbolic-equation">${math(`${row.symbolicLabelLatex || row.labelLatex} = ${row.symbolicLatex}`, true)}</div>`;
    return `<div class="worked-equation">${symbolic}${math(source, true)}</div>`;
}

/** Round scalar readouts in the short view; the detailed view retains fractions. */
export function compactEquationHtml(row          )         {
    const scalar = /^(-?\d+)(?:\/(\d+))?$/.exec(row.exact);
    if (!scalar) return equationHtml(row);
    const numerator = Number(scalar[1]);
    const denominator = Number(scalar[2] || '1');
    const value = numerator / denominator;
    if (!Number.isFinite(value)) return equationHtml(row);
    const rounded = Number(value.toPrecision(6));
    const displayed = numberLatex(rounded, 7);
    // Compare decimal and rational values with integers, avoiding a false '='
    // when binary floating point rounds two distinct rationals to one value.
    const [coefficient, power = '0'] = String(rounded).split('e');
    const [whole, fraction = ''] = coefficient.split('.');
    const exponent = Number(power) - fraction.length;
    const decimalNumerator = BigInt(whole + fraction) * 10n ** BigInt(Math.max(0, exponent));
    const decimalDenominator = 10n ** BigInt(Math.max(0, -exponent));
    const approximate = decimalNumerator * BigInt(scalar[2] || '1') !== BigInt(scalar[1]) * decimalDenominator;
    return equationHtml({ ...row, latex: displayed, approximate: row.approximate || approximate });
}

/** Keep derivation steps symbolic; numerical arithmetic belongs at evaluation. */
export function symbolicEquationHtml(row          )         {
    return math(`${row.symbolicLabelLatex || row.labelLatex} = ${row.symbolicLatex ?? row.latex}`, true);
}

/** Shared equations remain ordinary LaTeX that an instructor can edit. */
export const methodRules = {
    sections: String.raw`\begin{aligned}
        N(x)&=-\sum_{x_i\le x}F_{x,i},\\
        V(x)&=\sum_{x_i\le x}F_{y,i}-\int_0^x w(s)\,\mathrm{d}s,\\
        M(x)&=\sum_{x_i\le x}F_{y,i}(x-x_i)-\sum_{x_i\le x}C_i
            -\int_0^x w(s)(x-s)\,\mathrm{d}s.
        \end{aligned}`,
    integration: String.raw`\begin{aligned}
        EI\,v_i''(x)&=M_i(x),\\
        EI\,\theta_i(x)=EI\,v_i'(x)&=\int M_i(x)\,\mathrm{d}x+C_{2i-1},\\
        EI\,v_i(x)&=\int EI\,\theta_i(x)\,\mathrm{d}x+C_{2i}.
        \end{aligned}`,
    conditions: String.raw`\begin{aligned}
        v(a)&=v(b)=0,\\
        v(x_i^-)&=v(x_i^+), & \theta(x_i^-)&=\theta(x_i^+).
        \end{aligned}`,
    area: String.raw`\begin{aligned}
        \theta_Q-\theta_P&=\int_{x_P}^{x_Q}\frac{M(x)}{EI}\,\mathrm{d}x,\\
        t_{Q/P}&=\int_{x_P}^{x_Q}(x_Q-x)\frac{M(x)}{EI}\,\mathrm{d}x,\\
        v_Q&=v_P+(x_Q-x_P)\theta_P+t_{Q/P}.
        \end{aligned}`,
    virtual: String.raw`\begin{aligned}
        \bar P\Delta_{s\mathrm v}&=\sum_i\int\frac{\bar M_i M_i}{EI}\,\mathrm{d}x,&\bar M_i&=\bar Pm_i,\\
        \Delta_{s\mathrm v}&=\sum_i\int\frac{m_i M_i}{EI}\,\mathrm{d}x=-v(x_s).
        \end{aligned}`,
};
