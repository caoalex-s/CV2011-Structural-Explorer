/** Course labels and member-end connections shared by the canvas and inspector. */
import { endConnection, nodeLabels } from './engine.js';
                                                        

                            
                 
               
 

export function memberLabel(model       , member        )         {
    const labels = nodeLabels(model);
    return `${labels.get(member.a)}–${labels.get(member.b)}`;
}

export function jointConnections(model       , node       ) {
    return model.members
        .filter(member => member.a === node.id || member.b === node.id)
        .map(member => {
            const end = member.a === node.id ? 'a' : 'b';
            return { member, end: end             , rule: endConnection(model, member, end) };
        });
}
